# Movie-Recommender-Project
This is a Movie Recommender Project I developed as the Capstone for [Duke University's Java Programming and Software Engineering Fundamentals Specialisation on Coursera](https://www.coursera.org/specializations/java-programming)

[Certificate for completing the Specialisation](https://www.coursera.org/account/accomplishments/specialization/certificate/X28ZZXW4TNRY)

Try it for yourself! Get some awesome movie recommendations at [INSERT LINK TO DUKE'S WEBSITE RUNNING MY CODE]

Functionality of each class: [INSERT CLASSES AND DETAILS ABOUT THEIR FUNCTIONALITY]
